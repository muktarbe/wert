public class Person {
    String fullname;
    int age;
    String gender;

    @Override
    public String toString() {
        return "Person{" +
                "fullname='" + fullname + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                '}';
    }

    public Person(String fullname, int age, String gender) {
        this.fullname = fullname;
        this.age = age;
        this.gender = gender;

    }
}